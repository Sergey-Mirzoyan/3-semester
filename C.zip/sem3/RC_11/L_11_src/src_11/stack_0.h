#ifndef _STACK_0_H_

#define _STACK_0_H_

#include <stdbool.h>

void make_empty(void);

bool is_empty(void);

bool is_full(void);

int push(int i);

int pop(int *i);

#endif