#include <stdio.h>
#include <assert.h>
#include "stack_0.h"

int main(void)
{
    int     i;
    int     rc;

    make_empty();

    i = 0;
    while (!is_full())
    {
        rc = push(i);

        assert(rc == 0);

        i++;
    }

    while (!is_empty())
    {
        rc = pop(&i);

        assert(rc == 0);

        printf("%d\n", i);
    }

    return 0;
}