#include <stdlib.h>
#include "stack_4.h"


struct stack_type
{
    item_t* content;
    int top;
    int size;

};


stack_t create(int size)
{
    stack_t s = malloc(sizeof(struct stack_type));

    if (s)
    {
        s->content = malloc(size * sizeof(item_t));

        if (s->content)
        {
            s->size = size;

            make_empty(s);
        }
        else
        {
            free(s);

            s = NULL;
        }
    }

    return s;
}


void destroy(stack_t s)
{
    free(s->content);
    free(s);
}


void make_empty(stack_t s)
{
    s->top = 0;
}


bool is_empty(const stack_t s)
{
    return s->top == 0;
}


bool is_full(const stack_t s)
{
    return s->top == s->size;
}


int push(stack_t s, item_t i)
{
    if (is_full(s))
        return -1;

    s->content[(s->top)++] = i;

    return 0;
}


int pop(stack_t s, item_t *i)
{
    if (is_empty(s))
        return -1;

    *i = s->content[--(s->top)];

    return 0;
}
