#include <stdio.h>
#include <assert.h>
#include "stack_4.h"

int main(void)
{
    stack_t s;
    item_t  i;
    int     rc;

    s = create(10);

    i = 0;
    while (!is_full(s))
    {
        rc = push(s, i);

        assert(rc == 0);

        i++;
    }

    while (!is_empty(s))
    {
        rc = pop(s, &i);

        assert(rc == 0);

        printf("%d\n", i);
    }

    destroy(s);

    return 0;
}