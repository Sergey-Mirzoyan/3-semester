#include <stdio.h>
#include <assert.h>
#include "stack_1.h"

int main(void)
{
    stack_t s;
    int     i;
    int     rc;

    make_empty(&s);

    i = 0;
    while (!is_full(&s))
    {
        rc = push(&s, i);

        assert(rc == 0);

        i++;
    }

    while (!is_empty(&s))
    {
        rc = pop(&s, &i);

        assert(rc == 0);

        printf("%d\n", i);
    }

    return 0;
}