#include <stdio.h>
#include <assert.h>
#include "stack_5.h"

int main(void)
{
    stack_t s;
    item_t  i;
    int     rc;

    s = create();

    for (i = 0; i < 10; i++)
    {
        rc = push(s, i);

        assert(rc == 0);
    }

    while (!is_empty(s))
    {
        rc = pop(s, &i);

        assert(rc == 0);

        printf("%d\n", i);
    }

    destroy(s);

    return 0;
}