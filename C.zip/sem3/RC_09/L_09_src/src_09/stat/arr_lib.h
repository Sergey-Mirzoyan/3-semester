#ifndef __ARR__LIB__H__

#define __ARR__LIB__H__

void arr_form(int *arr, int n);

void arr_print(const int *arr, int n);

#endif  // __ARR__LIB__H__
