import example_dll

print(example_dll.add(5, 7))

print(example_dll.add(4, -2))

print(example_dll.divide(4, 5))

print(example_dll.divide(10, 5))

print(example_dll.fill_array(10))

print(example_dll.fill_array(5))

print(example_dll.avg((1, 2, 3)))

print(example_dll.avg_2((1.0, 2.0, 3.0)))

print(example_dll.avg_2((1, 2, 3)))