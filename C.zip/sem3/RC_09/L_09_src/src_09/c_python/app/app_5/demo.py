import example_dll

print(example_dll.add(5, 7))

print(example_dll.add(4, -2))

print(example_dll.divide(4, 5))

print(example_dll.divide(10, 5))