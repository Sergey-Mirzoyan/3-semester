#ifndef _EXAMPLE_H_

#define _EXAMPLE_H_

int add(int a, int b);

int divide(int a, int b, int *remainder);

#endif